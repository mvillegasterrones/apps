<link rel="stylesheet" type="text/css"
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

<link href="./assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="./assets/css/nucleo-svg.css" rel="stylesheet" />

<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

<link id="pagestyle" href="./assets/css/material-kit-pro.min.css?v=3.0.4" rel="stylesheet" />

<link rel="stylesheet" href="./assets/css/style.css" />

<link rel="stylesheet" href="./assets/css/animations-me.css" />

<!-- Estilos de AOS -->
<!--//*<link href="https://cdn.jsdelivr.net/npm/aos@2.3.1/dist/aos.css" rel="stylesheet">-->
<link rel="stylesheet" href="./assets/css/aos.css" />
<script src="./assets/js/aos.js"></script>

<style>
    /*.async-hide {
        opacity: 0 !important
    }*/
</style>