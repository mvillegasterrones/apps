<div class="min-height-300 bg-primary position-absolute w-100"></div>
<?php //include './views/sections/slider.php' 
?>

<main class="main-content position-relative border-radius-lg">
    <?php include './Views/sections/nav-bar.php' ?>

    <div class="container-fluid py-4" id="view-main">
        <?php include './Views/form/main-inst.php' ?>
    </div>
</main>
<?php
    include './Views/form-modal/modal-reporte-inst-01.php';
    include './Views/form-modal/modal-reporte-inst-02.php';
    include './Views/form-modal/modal-reporte-inst-03.php';
    include './Views/form-modal/modal-reporte-enc-01.php';
    include './Views/form-modal/modal-reporte-enc-02.php';
?>