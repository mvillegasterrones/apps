<?php

$pregunta_06 = array(

);

$section_1 = array(
    'Proyecto Educativo Institucional - PEI',
    'Reglamento Interno - RI',
    'Plan Anual de Trabajo - PAT',
    'Proyecto Curricular de la IE - PCI/ Plan de Formación-PF',
    'Manual de funcionamiento del MSE',
    'Plan de gestión del bienestar del MSE',
    'Plan del TOECE de la IE',
    'Plan de TOECE del Aula',
    'Ninguno ',
);

$section_2 = array(
    'Tutoría y orientación al estudiante',
    'Promoción de la salud en adolescentes',
    'Educación sexual integral',
    'Prevención y protocolos frente a la violencia',
    'Apoyo socioemocional al estudiante y su familia',
    'Gestión de servicios constitutivos (alimentación, salud, identidad y buen trato',
    'Participación estudiantil',
    'Orientación vocacional',
    'Uso del botiquín y primeros auxilios',
    'Ninguno',
    'Otro (especifique)',
);

$section_3 = array(
    'Educación sexual integral',
    'Habilidades socioemocionales',
    'Prevención del embarazo',
    'Prevención de la trata y explotación sexual',
    'Prevención de la violencia',
    'Convivencia escolar',
    'Orientación vocacional',
    'Proyecto de vida',
    'Ninguno',
    'Otro (especifique)',
);
