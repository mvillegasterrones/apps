/* // * LGIN */
btn_login.click( () => {
    user().set_login()
})