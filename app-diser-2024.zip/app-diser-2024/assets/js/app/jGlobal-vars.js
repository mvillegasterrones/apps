/*// * Login - Usuario */
let login_url     = './Controllers/cUsuario.php'
let btn_login     = $('#form-login #btn-login')
let login_cod_mod = $('#form-login #cod_mod')
/*// * End Login - usuario */

/*// * Form - Instrumento 01 */
let questionario_url = './Controllers/cQuestionario.php'
let form_inst_01     = $('#form-inst-01')

/*// * Form - Instrumento 02 */
let form_inst_02     = $('#form-inst-02')

let admin_url = './Controllers/cAdmin.php'