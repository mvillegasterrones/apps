<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- MDB -->
<script src="./js/pro.mdb.umd.min.js"></script>
<!-- MyScripts -->
<script src="./js/scripts.js"></script>
<script>
    /*document.addEventListener("DOMContentLoaded", function() {
        const frases = document.querySelector('.frases');
        const spanFrases = frases.querySelectorAll('div');
        let index = 0;

        function pasarFrase() {
            index = (index + 1) % spanFrases.length;
            frases.style.transform = `translateY(-${index * 100}%)`;
        }

        setInterval(pasarFrase, 6000); // ajusta el intervalo de tiempo según tus necesidades
    });*/
</script>