<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECEGP | Proyectos de Innovación Empresarial</title>
</head>
<body>
    <h1>Proyectos de Innovación Empresarial</h1>
</body>
</html>